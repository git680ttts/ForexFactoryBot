import os
import requests
from datetime import datetime
from playwright.sync_api import sync_playwright
import pytz

DISCORD_WEBHOOK = os.getenv("DISCORD_WEBHOOK")  # set in GitHub Secrets

CURRENCIES = {"EUR", "GBP", "USD", "CAD", "AUD", "CHF"}

def scrape_forexfactory():
    url = "https://www.forexfactory.com/calendar?day=today"
    events = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=60000)
        page.wait_for_selector("table.calendar__table")

        rows = page.query_selector_all("tr.calendar__row")
        for row in rows:
            try:
                currency = row.query_selector(".calendar__currency").inner_text().strip()
                if currency not in CURRENCIES:
                    continue

                time_text = row.query_selector(".calendar__time").inner_text().strip()
                impact_el = row.query_selector(".impact")
                impact = impact_el.get_attribute("title") if impact_el else "N/A"
                event_name = row.query_selector(".calendar__event").inner_text().strip()
                actual = row.query_selector(".calendar__actual").inner_text().strip()
                forecast = row.query_selector(".calendar__forecast").inner_text().strip()
                previous = row.query_selector(".calendar__previous").inner_text().strip()

                events.append({
                    "time": time_text,
                    "currency": currency,
                    "impact": impact,
                    "event": event_name,
                    "actual": actual,
                    "forecast": forecast,
                    "previous": previous
                })
            except Exception:
                continue

        browser.close()
    return events

def format_message(events):
    if not events:
        return "No events found for EUR, GBP, USD, CAD, AUD, CHF today."

    lines = []
    for ev in events:
        line = f"**{ev['time']} {ev['currency']}** — {ev['event']} ({ev['impact']})"
        extras = []
        if ev['forecast']: extras.append(f"F: {ev['forecast']}")
        if ev['previous']: extras.append(f"P: {ev['previous']}")
        if ev['actual']: extras.append(f"A: {ev['actual']}")
        if extras:
            line += " | " + " ".join(extras)
        lines.append(line)
    return "\n".join(lines)

def post_to_discord(message):
    payload = {"content": message}
    requests.post(DISCORD_WEBHOOK, json=payload)

if __name__ == "__main__":
    # Check London time
    london = pytz.timezone("Europe/London")
    now_london = datetime.now(london)

    if now_london.strftime("%H:%M") != "00:55":
        print(f"⏰ Not 00:55 London (current: {now_london.strftime('%H:%M')}). Skipping.")
    else:
        events = scrape_forexfactory()
        message = f"📅 **Forex Factory Calendar — {now_london.strftime('%Y-%m-%d')}**\n\n"
        message += format_message(events)
        post_to_discord(message)
        print("✅ Posted to Discord.")
